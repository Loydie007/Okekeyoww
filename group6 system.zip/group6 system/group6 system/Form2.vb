﻿Public Class Form2
    Private Sub MANAGEToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MANAGEToolStripMenuItem.Click
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub LISTToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LISTToolStripMenuItem.Click
        Form4.Show()
        Me.Hide()
    End Sub

    Private Sub EXITToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EXITToolStripMenuItem.Click
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to log out?", "Logout Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If result = DialogResult.Yes Then
            Close()

        End If
    End Sub

    Private Sub HELPToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HELPToolStripMenuItem.Click

    End Sub

    Private Sub SETTINGSToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SETTINGSToolStripMenuItem.Click

    End Sub
End Class