﻿Public Class Form4
    Private rowIndexToPrint As Integer

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadDataFromForm3()
    End Sub

    Private Sub LoadDataFromForm3()
        ' Call the loadTable function from Form3 to load the data
        Form3.loadTable()
        ' Transfer the data from Form3.DataGridView1 to Form4.DataGridView1
        DataGridView1.DataSource = Form3.DataGridView1.DataSource
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' Set the rowIndexToPrint to the index of the selected row in DataGridView1
        If DataGridView1.SelectedRows.Count > 0 Then
            rowIndexToPrint = DataGridView1.SelectedRows(0).Index
            If PrintDialog1.ShowDialog = DialogResult.OK Then
                PrintDocument1.Print()
            End If
        Else
            MessageBox.Show("Please select a row to print.")
        End If
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        ' Calculate the total height of the printed area
        Dim totalHeight As Integer = 0
        For Each cell As DataGridViewCell In DataGridView1.Rows(rowIndexToPrint).Cells
            totalHeight += cell.ContentBounds.Height
        Next

        ' Create a bitmap to draw the row to print
        Dim bm As New Bitmap(DataGridView1.Width, totalHeight)

        ' Create a graphics object from the bitmap
        Dim g As Graphics = Graphics.FromImage(bm)

        ' Define the starting y-coordinate for drawing
        Dim yPos As Integer = 0

        ' Loop through each cell in the row and draw its content onto the bitmap
        For Each cell As DataGridViewCell In DataGridView1.Rows(rowIndexToPrint).Cells
            ' Get the bounds of the cell content
            Dim cellBounds As Rectangle = New Rectangle(0, yPos, cell.ContentBounds.Width, cell.ContentBounds.Height)

            ' Create a cell drawing rectangle with padding
            Dim cellRect As New Rectangle(cellBounds.Left + 1, cellBounds.Top + 1, cellBounds.Width - 2, cellBounds.Height - 2)

            ' Draw the cell background
            g.FillRectangle(New SolidBrush(cell.Style.BackColor), cellBounds)

            ' Draw the cell content
            TextRenderer.DrawText(g, cell.FormattedValue.ToString(), cell.Style.Font, cellRect, cell.Style.ForeColor, TextFormatFlags.Left Or TextFormatFlags.VerticalCenter Or TextFormatFlags.WordBreak)

            ' Move to the next row position
            yPos += cellBounds.Height
        Next

        ' Draw the bitmap onto the print document
        e.Graphics.DrawImage(bm, e.MarginBounds.Location)
    End Sub
End Class
