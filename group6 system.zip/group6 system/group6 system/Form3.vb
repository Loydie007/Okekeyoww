﻿Imports MySql.Data.MySqlClient

Public Class Form3
    Dim con As MySqlConnection = New MySqlConnection("server=localhost;username=root;password=;database=tnd_db")
    Dim cmd As New MySqlCommand()
    Dim adapter As New MySqlDataAdapter()
    Dim data As New DataTable()
    Dim table As New DataTable()

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Open database connection
        openCon()
        Try
            ' Execute INSERT query
            cmd.Connection = con
            cmd.CommandText = "INSERT INTO tbl_db (ID_NO, Declarant, Address, Spouse, Position, Office) VALUES ('" &
                txtID_NO.Text & "', '" & txtDeclarant.Text & "', '" & txtAddress.Text & "', '" & txtSpouse.Text & "', '" &
                txtPosition.Text & "', '" & txtOffice.Text & "')"
            cmd.ExecuteNonQuery()
            MsgBox("Successfully Added Record!")
            ' Close database connection
            con.Close()
            ' Reload data into DataGridView
            loadTable()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Open database connection
        openCon()
        MsgBox("Connected!")
        ' Close database connection
        con.Close()
        ' Load data into DataGridView
        loadTable()
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick


        ' Get data from selected row in DataGridView
        Dim selectedIDNO As String = DataGridView1.CurrentRow.Cells("ID_NO").Value.ToString()
        Dim selectedDeclarant As String = DataGridView1.CurrentRow.Cells("Declarant").Value.ToString()
        Dim selectedAddress As String = DataGridView1.CurrentRow.Cells("Address").Value.ToString()
        Dim selectedSpouse As String = DataGridView1.CurrentRow.Cells("Spouse").Value.ToString()
        Dim selectedPosition As String = DataGridView1.CurrentRow.Cells("Position").Value.ToString()
        Dim selectedOffice As String = DataGridView1.CurrentRow.Cells("Office").Value.ToString()

        ' Pass the retrieved data to TextBoxes
        txtID_NO.Text = selectedIDNO
        txtDeclarant.Text = selectedDeclarant
        txtAddress.Text = selectedAddress
        txtSpouse.Text = selectedSpouse
        txtPosition.Text = selectedPosition
        txtOffice.Text = selectedOffice
    End Sub

    Private Sub txtID_NO_TextChanged(sender As Object, e As EventArgs)
        ' Open database connection
        openCon()
        Try
            ' Execute SELECT query
            cmd.Connection = con
            cmd.CommandText = "SELECT * FROM tbl_db WHERE ID_NO='" & txtID_NO.Text & "'"
            adapter.SelectCommand = cmd
            data.Clear()
            ' Close database connection
            con.Close()

            If data.Rows.Count > 0 Then
                ' Populate TextBoxes with retrieved data
                txtDeclarant.Text = data.Rows(0)("Declarant").ToString()
                txtAddress.Text = data.Rows(0)("Address").ToString()
                txtSpouse.Text = data.Rows(0)("Spouse").ToString()
                txtPosition.Text = data.Rows(0)("Position").ToString()
                txtOffice.Text = data.Rows(0)("Office").ToString()
            Else
                ' Clear TextBoxes if no data found
                clearFields()
            End If

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Sub loadTable()
        ' Open database connection
        openCon()
        Try
            ' Execute SELECT query
            cmd.Connection = con
            cmd.CommandText = "SELECT * FROM tbl_db"
            adapter.SelectCommand = cmd
            table.Clear()
            ' Fill DataTable with retrieved data
            adapter.Fill(table)
            ' Bind DataTable to DataGridView
            DataGridView1.DataSource = table
            ' Close database connection
            con.Close()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ' Open database connection
        openCon()
        Try
            ' Execute UPDATE query
            cmd.Connection = con
            cmd.CommandText = "UPDATE tbl_db SET Declarant = '" & txtDeclarant.Text & "', Address = '" & txtAddress.Text &
                "', Spouse = '" & txtSpouse.Text & "', Position = '" & txtPosition.Text &
                "', Office = '" & txtOffice.Text & "' WHERE ID_NO = '" & txtID_NO.Text & "'"
            cmd.ExecuteNonQuery()
            ' Close database connection
            con.Close()
            MsgBox("Successfully Updated Record!")
            ' Reload data into DataGridView
            loadTable()
            ' Clear TextBoxes
            clearFields()
        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim selectedIDNO As String = Nothing

        If DataGridView1.CurrentRow IsNot Nothing Then
            selectedIDNO = DataGridView1.CurrentRow.Cells("ID_NO").Value.ToString()

            If MessageBox.Show("Are you sure you want to delete this record?", "Confirmation", MessageBoxButtons.YesNo) = DialogResult.Yes Then
                ' Open database connection
                openCon()
                Try
                    ' Execute DELETE query
                    cmd.Connection = con
                    cmd.CommandText = "DELETE FROM tbl_db WHERE ID_NO = @IDNO"
                    cmd.Parameters.Clear() ' Clear any previously defined parameters
                    cmd.Parameters.AddWithValue("@IDNO", selectedIDNO) ' Add the parameter again
                    cmd.ExecuteNonQuery()
                    ' Close database connection
                    con.Close()

                    MsgBox("Record deleted successfully!")
                    ' Reload data into DataGridView
                    loadTable()
                Catch ex As MySqlException
                    If ex.Number = 1451 Then
                        MessageBox.Show("Cannot delete this record because it is referenced by another table. Please delete the related records first.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    Else
                        MessageBox.Show(ex.ToString())
                    End If
                Catch ex As Exception
                    MessageBox.Show(ex.ToString())
                End Try
            End If
        Else
            MsgBox("Please select a record to delete.")
        End If
    End Sub

    Private Sub clearFields()
        ' Clear TextBoxes
        txtID_NO.Clear()
        txtDeclarant.Clear()
        txtAddress.Clear()
        txtSpouse.Clear()
        txtPosition.Clear()
        txtOffice.Clear()
    End Sub

    Private Sub openCon()
        ' Open database connection if it's closed
        If con.State = ConnectionState.Closed Then
            con.Open()
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        ' Open Form2
        Form2.Show()
        ' Hide Form3
        Me.Hide()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        txtID_NO.Clear()
        txtDeclarant.Clear()
        txtAddress.Clear()
        txtSpouse.Clear()
        txtPosition.Clear()
        txtOffice.Clear()
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub
End Class
